import './globals.css'

export const metadata = {
  title: 'Finance Admin',
  description: 'Finance admin dashboard'
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}

